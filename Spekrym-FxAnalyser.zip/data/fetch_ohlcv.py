import asyncio
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import text

from data.db import get_session
from data.oanda_client import OandaClient, CircuitOpenError

logger = logging.getLogger("fetch_ohlcv")

PAIRS = ["EUR_USD", "GBP_USD", "USD_JPY", "AUD_USD", "USD_CAD"]
GRANULARITY = "H1"
MAX_CANDLES_PER_REQUEST = 5000
BACKFILL_YEARS = 2

UPSERT_SQL = text(
    """
    INSERT INTO candles (pair, ts, o, h, l, c, v, complete)
    VALUES (:pair, :ts, :o, :h, :l, :c, :v, :complete)
    ON CONFLICT (pair, ts) DO UPDATE SET
        o = EXCLUDED.o, h = EXCLUDED.h, l = EXCLUDED.l,
        c = EXCLUDED.c, v = EXCLUDED.v, complete = EXCLUDED.complete
    """
)


def _to_row(pair: str, candle: dict) -> dict:
    mid = candle["mid"]
    return {
        "pair": pair,
        "ts": datetime.fromisoformat(candle["time"].replace("Z", "+00:00")),
        "o": float(mid["o"]),
        "h": float(mid["h"]),
        "l": float(mid["l"]),
        "c": float(mid["c"]),
        "v": int(candle["volume"]),
        "complete": bool(candle["complete"]),
    }


async def _store_candles(pair: str, candles: list[dict]):
    if not candles:
        return
    rows = [_to_row(pair, c) for c in candles]
    async with get_session() as session:
        await session.execute(UPSERT_SQL, rows)
        await session.commit()
    logger.info("stored %d candles for %s", len(rows), pair)


async def backfill_pair(client: OandaClient, pair: str, years: int = BACKFILL_YEARS):
    """Paginate backward in MAX_CANDLES_PER_REQUEST chunks to cover `years` of H1 candles."""
    to_time = datetime.now(timezone.utc)
    since = to_time - timedelta(days=365 * years)
    cursor = to_time

    while cursor > since:
        try:
            candles = await client.get_candles(
                pair, granularity=GRANULARITY, count=MAX_CANDLES_PER_REQUEST,
                to_time=cursor.strftime("%Y-%m-%dT%H:%M:%S.000000000Z"),
            )
        except CircuitOpenError:
            logger.warning("breaker open, aborting backfill for %s", pair)
            break

        if not candles:
            break

        await _store_candles(pair, candles)
        earliest = datetime.fromisoformat(candles[0]["time"].replace("Z", "+00:00"))
        if earliest >= cursor:
            break
        cursor = earliest - timedelta(hours=1)


async def backfill_all(years: int = BACKFILL_YEARS):
    client = OandaClient()
    try:
        for pair in PAIRS:
            logger.info("backfilling %s (%dy)", pair, years)
            await backfill_pair(client, pair, years)
    finally:
        await client.close()


async def poll_latest(client: OandaClient, pair: str):
    """Fetch the last few candles (covers late/partial updates) and upsert."""
    try:
        candles = await client.get_candles(pair, granularity=GRANULARITY, count=3)
    except CircuitOpenError:
        logger.warning("breaker open, skipping poll for %s", pair)
        return
    await _store_candles(pair, candles)


async def poll_all_once():
    client = OandaClient()
    try:
        for pair in PAIRS:
            await poll_latest(client, pair)
    finally:
        await client.close()


def seconds_until_next_hour(buffer_s: int = 5) -> float:
    now = datetime.now(timezone.utc)
    nxt = (now + timedelta(hours=1)).replace(minute=0, second=0, microsecond=0)
    return (nxt - now).total_seconds() + buffer_s


async def live_poll_loop():
    """Aligns polling to just after each H1 candle close."""
    while True:
        await asyncio.sleep(seconds_until_next_hour())
        try:
            await poll_all_once()
        except Exception:
            logger.exception("live poll cycle failed")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(backfill_all())