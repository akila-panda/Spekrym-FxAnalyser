import pandas as pd
from sqlalchemy import text

from data.db import get_session

TIMEFRAME_RULE = {
    "H1": None,
    "H4": "4h",
    "D1": "1D",
}


async def load_candles(pair: str, timeframe: str = "H1", limit: int = 500) -> pd.DataFrame:
    """Load H1 candles from Postgres, resample to requested timeframe."""
    fetch_limit = limit
    if timeframe == "H4":
        fetch_limit = limit * 4
    elif timeframe == "D1":
        fetch_limit = limit * 24

    async with get_session() as session:
        result = await session.execute(
            text(
                """
                SELECT ts, o, h, l, c, v FROM candles
                WHERE pair = :pair AND complete = TRUE
                ORDER BY ts DESC LIMIT :lim
                """
            ),
            {"pair": pair, "lim": fetch_limit},
        )
        rows = result.fetchall()

    if not rows:
        return pd.DataFrame(columns=["ts", "o", "h", "l", "c", "v"])

    df = pd.DataFrame(rows, columns=["ts", "o", "h", "l", "c", "v"]).iloc[::-1].reset_index(drop=True)
    df["ts"] = pd.to_datetime(df["ts"], utc=True)
    df = df.set_index("ts")

    rule = TIMEFRAME_RULE.get(timeframe)
    if rule:
        df = df.resample(rule).agg(
            {"o": "first", "h": "max", "l": "min", "c": "last", "v": "sum"}
        ).dropna()

    return df.tail(limit).reset_index()